# Change Log

## 1.1.0

- ISO 4217 currency codes are introduced as enum
- Overloaded constructor for Money with Currency enum 
- Overloaded Wallet.Evaluate() method with Currency enum
- Money constructor with string currency remains in this version (obsolete) and will be removed in next version
- Wallet.Evaluate() with string currency remains in this version (obsolete) and will be removed in the next version
 


## 1.0.0

- Initial release